<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Нейросистема-7</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/fonts.css">
    <link rel="stylesheet" href="css/media.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="shortcut icon" href="/icon.ico" type="image/x-icon">

    
</head>

<body>
   
    <header>
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="logo">
                            <img src="img/logo.png" alt="">
                        </div>
                    </div>
                    <div class="col-sm-9">
                        <div class="descr hidden-xs">интеллектуальная формула <span>быстрого похудения</span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-7 col-md-8">
                        <div class="descr1 visible-xs">интеллектуальная формула <span>быстрого похудения</span></div>
                        <div class="descr">Сбросьте лишний вес всего <span>за 7 дней</span></div>
                        <div class="spisok">
                            <ul class="header-ul">
                                <li>Экспресс-потеря веса <span>до 7 кг в неделю</span></li>
                                <li><span>Уничтожение жировых клеток</span> изнутри с 1-го дня</li>
                                <li>Умное похудение <span>без вреда здоровью</span></li>
                            </ul>
                            <img src="img/prod1.png" alt="" class="prod1">
                        </div>
                    </div>
                    <div class="col-sm-5 col-md-4">
                        <div class="forma">
                            <div class="prices">
                                <div class="price-text"><span>только сегодня!</span> цена по акции:</div>
                                <div class="price__new">
                                    <span class="new_price_val">149</span>
                                    <span class="new_price_cur">р</span>
                                </div>
                                <div class="price__old">
                                    <div class="old_price-text">старая цена</div>
                                    <span class="old_price_val">2990</span>
                                </div>
                            </div>
                            <div class="countdown"></div>
                            <form action="js/mail.php" method="post" class="form landing__form">
							<input type="hidden" name="utm_source" value="">
            <input type="hidden" name="utm_medium" value="Anton lead">
            <input type="hidden" name="utm_campaign" value="">
            <input type="hidden" name="utm_content" value="">
            <input type="hidden" name="utm_term" value="">
                                <div class="form__list">
                                    <div class="form__item">
                                        
                                    </div>
                                    <div class="form__item">
                                        <input type="text" class="form__input" placeholder="Имя" name="name">
                                    </div>
                                    <div class="form__item">
                                        <input type="tel" class="form__input phone__mask" name="phone"
                                            placeholder="Телефон">
                                    </div>
                                    <div class="form__item">
                                        <button class="form__btn">заказать за
                                            <span class="price__new">
                                                <span class="new_price_val">149</span>
                                                <span class="new_price_cur">руб</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <div class="pri">*При заказе курса</div>
                            <div class="gost">
                                <img src="img/gost.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <section class="why">
        <div class="container">
            <div class="section-title">почему <span><span>вы </span>не можете</span> похудеть?</div>
            <div class="row">
                <div class="col-lg-1"></div>
                <div class="col-sm-6 col-lg-5">
                    <div class="why-img">
                        <img src="img/why-img1.png" alt="">
                    </div>
                </div>
                <div class="col-sm-6 col-lg-5">
                    <div class="why-text1">
                        <span>Традиционные способы</span> похудения <span>направлены на сжигание</span> лишних
                        накопленных <span>калорий</span> и обезвоживание организма, за счет чего можно наблюдать
                        <span>временную незначительную</span> потерю веса.
                    </div>
                </div>
                <div class="col-lg-1"></div>
            </div>
            <div class="row">
                <div class="col-lg-1"></div>
                <div class="col-sm-6 col-lg-5 hidden-xs">
                    <div class="why-text2">
                        При этом <span>количество жировых клеток не сокращается,</span> и вы спустя какое-то время
                        <span>снова набираете еще больше жировой ткани,</span> так как организм испытывает стресс.
                    </div>
                </div>
                <div class="col-sm-6 col-lg-5">
                    <div class="why-img">
                        <img src="img/why-img2.png" alt="">
                    </div>
                    <div class="why-text2 visible-xs">
                        При этом <span>количество жировых клеток не сокращается,</span> и вы спустя какое-то время
                        <span>снова набираете еще больше жировой ткани,</span> так как организм испытывает стресс.
                    </div>
                </div>
                <div class="col-lg-1"></div>
            </div>
        </div>
    </section>
    <section class="wait">
        <div class="container">
            <div class="row">
                <div class="col-lg-1"></div>
                <div class="col-md-12 col-lg-10">
                    <div class="section-title">что ждет дальше людей <span>с лишним <span>весом </span>?</span></div>
                </div>
                <div class="col-lg-1"></div>
            </div>
            <div class="row hidden-xs">
                <div class="col-md-1"></div>
                <div class="col-sm-4 col-md-2">
                    <div class="wait-item">
                        <img src="img/wait1.png" alt="">
                        <p><span>Ожирение внутренних органов</span> (сердце, печень, легкие) и нарушение
                            их работы</p>
                    </div>
                </div>
                <div class="col-sm-4 col-md-2">
                    <div class="wait-item">
                        <img src="img/wait2.png" alt="">
                        <p><span>Болезни сердца</span>
                            (самое распространенное - инфаркт миокарда)</p>
                    </div>
                </div>
                <div class="col-sm-4 col-md-2">
                    <div class="wait-item">
                        <img src="img/wait3.png" alt="">
                        <p><span>Сахарный диабет</span> последней стадии и инвалидность</p>
                    </div>
                </div>
                <div class="col-sm-6 col-md-2">
                    <div class="wait-item">
                        <img src="img/wait4.png" alt="">
                        <p><span>Ожирение крайней степени</span> с последующей деформацией опорно-двигательного аппарата
                        </p>
                    </div>
                </div>
                <div class="col-sm-6 col-md-2">
                    <div class="wait-item">
                        <img src="img/wait5.png" alt="">
                        <p><span>Бесплодие,
                                рак</span> одинокая старость полная болезней</p>
                    </div>
                </div>
                <div class="col-md-1"></div>
            </div>
            <div class="visible-xs">
                <div class="owl-carousel owl1">
                    <div class="wait-item">
                        <img src="img/wait1.png" alt="">
                        <p><span>Ожирение внутренних органов</span> (сердце, печень, легкие) и нарушение
                            их работы</p>
                    </div>
                    <div class="wait-item">
                        <img src="img/wait2.png" alt="">
                        <p><span>Болезни сердца</span>
                            (самое распространенное - инфаркт миокарда)</p>
                    </div>
                    <div class="wait-item">
                        <img src="img/wait3.png" alt="">
                        <p><span>Сахарный диабет</span> последней стадии и инвалидность</p>
                    </div>
                    <div class="wait-item">
                        <img src="img/wait4.png" alt="">
                        <p><span>Ожирение крайней степени</span> с последующей деформацией опорно-двигательного аппарата
                        </p>
                    </div>
                    <div class="wait-item">
                        <img src="img/wait5.png" alt="">
                        <p><span>Бесплодие,
                                рак</span> одинокая старость полная болезней</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="bolen">
        <div class="container">
            <div class="row">
                <div class="col-lg-2"></div>
                <div class="col-lg-8">
                    <div class="section-title">
                        <span class="bolen1">16,5</span> миллионов человек <span class="bolen2">уже больны</span>
                    </div>
                </div>
                <div class="col-lg-2"></div>
            </div>
            <div class="row">
                <div class="col-lg-1"></div>
                <div class="col-sm-6 col-lg-5">
                    <div class="bolen-img">
                        <img src="img/bolen-img.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-1"></div>
                <div class="col-sm-6 col-lg-4">
                    <div class="bolen-text">
                        Согласно статистическим исследованиям ВОЗ, <span>более 16 с половиной миллионов больных
                            ожирением</span> имеют как минимум 3 из перечисленных заболевания! <span>С каждым годом эта
                            цифра растет!</span>
                    </div>
                </div>
                <div class="col-lg-1"></div>
            </div>
        </div>
    </section>
    <section class="test">
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-8">
                    <div class="section-title">
                        узнайте, насколько <span class="test1">опасно</span> <span class="test2">ваше состояние</span>
                    </div>
                </div>
                <div class="col-md-1"></div>
            </div>
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-8">
                    <div class="test-wrapper">
                        <div class="left">
                            <div class="left-input">
                                <input type="text" placeholder="Ваш возраст" class="inp1">
                            </div>
                            <div class="left-input">
                                <input type="text" placeholder="Ваш рост" class="inp2">
                            </div>
                            <div class="left-input">
                                <input type="text" placeholder="Ваш вес" class="inp3">
                            </div>
                        </div>
                        <div class="right">
                            <div class="line1" style="visibility: hidden">32</div>
                            <div class="line2" style="visibility: hidden">32</div>
                        </div>
                    </div>
                </div>
                <div class="col-md-1"></div>
            </div>
        </div>
    </section>
    <section class="tehn">
        <div class="container">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                    <div class="tehn-wrapper">
                        <div class="tehn-wrap">
                            <div class="section-title">
                                <span class="tehn1">молекулярные технологии</span>
                                <span class="tehn2">xxi века</span>
                                <span class="tehn3"> против лишнего веса</span>
                            </div>
                        </div>
                        <div class="tehn-items hidden-xs">
                            <div class="col-sm-4">
                                <div class="tehn-img">
                                    <img src="img/tehn1.png" alt="">
                                </div>
                            </div>
                            <div class="col-sm-8">
                                <div class="tehn-text">
                                    В <span>2016 году</span> группой ученых из разных стран, вкючая США, Германию,
                                    Японию и Россию, <span>был разработан и протестирован препарат</span> <span
                                        class="neyro">«НЕЙРОСИСТЕМА 7»</span>, аналогов которому <span>сегодня не
                                        существует.</span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="tehn-text tehn-text2">
                                    Это <span>препарат для похудения</span> на основе молекулярно синтезированного
                                    растительного волокна и экстрактов, <span>способный проникать</span> сквозь
                                    клеточную мембрану <span>разрушать жировые клетки изнутри.</span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="tehn-img">
                                    <img src="img/tehn2.png" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="tehn-items visible-xs">

                            <div class="tehn-img">
                                <img src="img/tehn1.png" alt="">
                            </div>

                            <div class="tehn-text">
                                В <span>2016 году</span> группой ученых из разных стран, вкючая США, Германию, Японию и
                                Россию, <span>был разработан и протестирован препарат</span> <span
                                    class="neyro">«НЕЙРОСИСТЕМА 7»</span>, аналогов которому <span>сегодня не
                                    существует.</span>
                            </div>
                            <div class="tehn-img">
                                <img src="img/tehn2.png" alt="">
                            </div>
                            <div class="tehn-text tehn-text2">
                                Это <span>препарат для похудения</span> на основе молекулярно синтезированного
                                растительного волокна и экстрактов, <span>способный проникать</span> сквозь клеточную
                                мембрану <span>разрушать жировые клетки изнутри.</span>
                            </div>



                        </div>
                    </div>
                    <div class="col-md-1"></div>
                </div>
            </div>
        </div>
    </section>
    <section class="days">
        <div class="container">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-8">
                    <div class="section-title">7 дней похудения с
                        <div class="logo">
                            <img src="img/logo2.png" alt="">
                        </div>

                        <img class="visible-xs kalend" src="img/kalend.png" alt="">

                    </div>
                </div>
                <div class="col-md-3"></div>
            </div>
            <div class="days-wrap">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="prod2">
                            <img src="img/prod2.png" alt="">
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-6">
                        <ul class="days-ul">
                            <li>Эффективное жиросжигание</li>
                            <li><span>Снижение тяги</span> к сладкой вредной еде</li>
                            <li><span>Ускорение</span> снижения веса</li>
                            <li><span>Нормализация</span> обмена веществ</li>
                            <li>Увеличение процесса жиросжигания</li>
                            <li><span>Избавление</span> от отеков</li>
                            <li><span>Снижение аппетита</span> и избавление от переедания</li>
                            <li><span>Тотальная блокировка</span> жировых отложений!</li>
                        </ul>
                    </div>
                    <div class="col-sm-1 col-md-2"></div>
                </div>
            </div>
        </div>
    </section>
    <section class="form-inline">
        <div class="container">
            <form action="js/mail.php" method="post" class="form landing__form">
			<input type="hidden" name="utm_source" value="">
            <input type="hidden" name="utm_medium" value="Anton lead">
            <input type="hidden" name="utm_campaign" value="">
            <input type="hidden" name="utm_content" value="">
            <input type="hidden" name="utm_term" value="">
                <div class="form__list">
                    <div class="row">
                        <div class="col-sm-6 col-md-3">
                            <div class="form__item">
                                
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="form__item">
                                <input type="text" class="form__input" placeholder="Имя" name="name">
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="form__item">
                                <input type="tel" class="form__input phone__mask" name="phone" placeholder="Телефон">
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <div class="form__item">
                                <button class="form__btn">заказать за
                                    <span class="price__new">
                                        <span class="new_price_val">149</span>
                                        <span class="new_price_cur">руб</span>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                    <p class="footnote">*При заказе курса</p>
                </div>
            </form>
        </div>
    </section>
    <section class="prinzip">
        <div class="container">
            <div class="section-title">ключевой принцип воздействия <span>"нейросистемы 7"</span></div>
            <div class="row">
                <div class="col-lg-1"></div>
                <div class="col-lg-10">
                    <div class="prinzip-wrapper">
                        <img src="img/strelka1.png" alt="" class="strelka1">
                        <img src="img/strelka2.png" alt="" class="strelka2 hidden-xs">
                        <img src="img/strelka3.png" alt="" class="strelka3">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="prinzip-item">
                                    <img src="img/prinz1.png" alt="">
                                    <p><span>Препарат дает специальному отделу мозга</span> сигнал о прекращении набора
                                        калорий, жировой прослойки и о снижении тяги к "вредной пище".</p>
                                </div>
                            </div>
                            <img src="img/strelka4.png" alt="" class="strelka4 visible-xs">
                            <div class="col-sm-6">
                                <div class="prinzip-item">
                                    <img src="img/prinz2.png" alt="">
                                    <p><span>Синтезированный комплекс</span> активных компонентов проникает сквозь
                                        клеточную мембрану и <span>уничтожает жировые клетки изнутри.</span></p>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-1"></div>
                            <div class="col-lg-10">
                                <div class="prinz-item">
                                    <div class="prinz-wrap"></div>
                                    <div class="prinz-text">«Нейросистема 7» - это комплексная борьба с лишним весом,
                                        включающая в себя 7 этапов.
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-1"></div>
            </div>
        </div>
    </section>
    <section class="steps">
        <div class="container">
            <img src="img/snake.png" alt="" class="snake">
            <div class="row">
                <div class="col-md-1 col-lg-2"></div>
                <div class="col-md-9 col-lg-7">
                    <div class="section-title">7 этапов похудения с
                        <div class="logo">
                            <img src="img/logo.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-md-2 col-lg-3"></div>
            </div>
            <div class="row hidden-xs">
                <div class="col-lg-1"></div>
                <div class="col-lg-10">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="steps-item">
                                <img src="img/day1.png" alt="" class="day-img">
                                <div class="day-item">
                                    <div class="day-title day1">01 день <span>подготовка</span></div>
                                    <p>организма к безопасному похудению и прекращение набора калорий </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="steps-item">
                                <img src="img/day2.png" alt="" class="day-img">
                                <div class="day-item">
                                    <div class="day-title day2">02 день <span>снижение</span></div>
                                    <p>аппетита и тяги к <br> сладкой, жирной и <br> вредной пище </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="steps-item">
                                <img src="img/day3.png" alt="" class="day-img">
                                <div class="day-item">
                                    <div class="day-title day3">03 день <span>запуск</span></div>
                                    <p>процесса уничтожения жировых клеток и сокращение жировой ткани</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="prod3">
                                <img src="img/prod3.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="steps-item">
                                        <img src="img/day5.png" alt="" class="day-img">
                                        <div class="day-item">
                                            <div class="day-title day5">05 день <span>преобразование</span></div>
                                            <p>жиров, белков и <br> углеводов в энергию </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="steps-item">
                                        <img src="img/day4.png" alt="" class="day-img">
                                        <div class="day-item">
                                            <div class="day-title day4">04 день <span>подавление</span></div>
                                            <p>процесса образования <br> новых жировых клеток (адипоцитов) </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="steps-item">
                                        <img src="img/day6.png" alt="" class="day-img">
                                        <div class="day-item">
                                            <div class="day-title day6">06 день <span>улучшение</span></div>
                                            <p>общего состояния всех систем организма </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="steps-item">
                                        <img src="img/day7.png" alt="" class="day-img">
                                        <div class="day-item">
                                            <div class="day-title day7">07 день <span>нормализация</span></div>
                                            <p>метаболизма, <br> перистальтики кишечника <br> и работы желудка </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-1"></div>
            </div>
            <div class="visible-xs">
                <div class="prod3">
                    <img src="img/prod3.png" alt="">
                </div>
                <div class="owl-carousel owl2">
                    <div class="steps-item">
                        <img src="img/day1.png" alt="" class="day-img">
                        <div class="day-item">
                            <div class="day-title day1">01 день <span>подготовка</span></div>
                            <p>организма к безопасному похудению и прекращение набора калорий </p>
                        </div>
                    </div>
                    <div class="steps-item">
                        <img src="img/day2.png" alt="" class="day-img">
                        <div class="day-item">
                            <div class="day-title day2">02 день <span>снижение</span></div>
                            <p>аппетита и тяги к <br> сладкой, жирной и <br> вредной пище </p>
                        </div>
                    </div>
                    <div class="steps-item">
                        <img src="img/day3.png" alt="" class="day-img">
                        <div class="day-item">
                            <div class="day-title day3">03 день <span>запуск</span></div>
                            <p>процесса уничтожения жировых клеток и сокращение жировой ткани</p>
                        </div>
                    </div>
                    <div class="steps-item">
                        <img src="img/day4.png" alt="" class="day-img">
                        <div class="day-item">
                            <div class="day-title day4">04 день <span>подавление</span></div>
                            <p>процесса образования <br> новых жировых клеток (адипоцитов) </p>
                        </div>
                    </div>
                    <div class="steps-item">
                        <img src="img/day5.png" alt="" class="day-img">
                        <div class="day-item">
                            <div class="day-title day5">05 день <span>преобразование</span></div>
                            <p>жиров, белков и <br> углеводов в энергию </p>
                        </div>
                    </div>

                    <div class="steps-item">
                        <img src="img/day6.png" alt="" class="day-img">
                        <div class="day-item">
                            <div class="day-title day6">06 день <span>улучшение</span></div>
                            <p>общего состояния всех систем организма </p>
                        </div>
                    </div>
                    <div class="steps-item">
                        <img src="img/day7.png" alt="" class="day-img">
                        <div class="day-item">
                            <div class="day-title day7">07 день <span>нормализация</span></div>
                            <p>метаболизма, <br> перистальтики кишечника <br> и работы желудка </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-1"></div>
        </div>
    </section>
    <section class="complex">
        <div class="container">

            <div class="row">
                <div class="col-sm-1"></div>
                <div class="col-sm-10">
                    <div class="section-title">
                        интеллектуальный <span>комплекс активных <span>компонентов</span></span>
                    </div>
                </div>
                <div class="col-sm-1"></div>
            </div>
            <img src="img/prod4.png" alt="" class="prod4 hidden-xs">
            <img src="img/prod6.png" alt="" class="prod4 visible-xs">
            <div class="row">
                <div class="col-sm-5">
                    <div class="complex-item">
                        <img src="img/comp1.png" alt="">
                        <div class="complex-text">
                            <span>экстракт фенхеля</span>
                            <p>Проникает сквозь мембрану жировых клеток и расщепляет их изнутри</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-2"></div>
                <div class="col-sm-5 visible-xs">
                    <div class="complex-item pos">
                        <img src="img/comp3.png" alt="">
                        <div class="complex-text">
                            <span>экстракт корня якона</span>
                            <p>Очищает организм от шлаков и токсинов, сокращает жировую прослойку</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-5">
                    <div class="complex-item">
                        <img src="img/comp2.png" alt="">
                        <div class="complex-text">
                            <span>Синефрин 6%</span>
                            <p>Участвует в транслировании сигнала о прекращении набора лишних калорий</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-5 hidden-xs">
                    <div class="complex-item">
                        <img src="img/comp3.png" alt="">
                        <div class="complex-text">
                            <span>экстракт корня якона</span>
                            <p>Очищает организм от шлаков и токсинов, сокращает жировую прослойку</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-2"></div>
                <div class="col-sm-5">
                    <div class="complex-item pos">
                        <img src="img/comp4.png" alt="">
                        <div class="complex-text">
                            <span>пиколинат хрома</span>
                            <p>Препятствует образванию новых жировых клеток, программирует метаболизм</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="expert">
        <div class="container">
            <img src="img/prod5.png" alt="" class="prod5">
            <div class="row">
                <div class="col-sm-4 col-md-5"></div>
                <div class="col-sm-8 col-md-7">
                    <div class="expert-wrapper">
                        <div class="section-title">эксперты <span>говорят</span></div>
                        <p>Как диетолог со стажем и автор многочисленных работ о снижении веса <span>я хочу отметить
                                исключительные качества «НЕЙРОСИСТЕМЫ 7» в борьбе с лишним весом.</span> В отличие от
                            всех известных препаратов, «НЕЙРОСИСТЕМА 7» уничтожает сами жировые клетки. Это кардинально
                            перестраивает ваш организм. </p>
                        <p>Сколько бы вы после похудения ни кушали, все равно жиру отладываться будет негде. Ну, и,
                            конечно же, прекращение набора веса происходит на нейронном уровне в особом отделе головного
                            мозга. <span>Это стопроцентная гарантия похудения. Лучше препарата я не встречал.</span>
                            Более того, он не содержит гормонов</p>
                        <div class="podpis">
                            <span>Виталий Симонов,</span>
                            врач-диетолог, к.м.н., <br>
                            автор серии книг по диетологии
                            <img src="img/rospis.png" alt="" class="rosp-img">
                        </div>
                        <a href="#form" class="zak">заказать за
                            <span class="price__new">
                                <span class="new_price_val">149</span>
                                <span class="new_price_cur">руб</span>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="reviews">
        <div class="container">
            <div class="row">
                <div class="col-sm-1"></div>
                <div class="col-sm-10">
                    <div class="reviews-wrapper">
                        <div class="reviews-wrap">
                            <div class="section-title"><span>отзывы</span> наших клиентов</div>
                        </div>
                        <div class="reviews-items hidden-xs">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="rev-text rev-text-left">
                                        <p>Мне 36 лет, худела на <br>
                                            <span>НЕЙРОСИСТЕМЕ 7</span> два <br>
                                            месяца. Никто не поверил, что это я! <br>
                                            Думали подменили:))))</p>
                                        <span>Алина, г. Москва</span>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="rev-img">
                                        <img src="img/rev1.png" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="rev-img">
                                        <img src="img/rev2.png" alt="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="rev-text rev-text-right">
                                        <p>Мне 41. Подруга рекомендовала <br>
                                            пропить курс <span>НЕЙРОСИСТЕМЫ 7</span>. Самая приятная диета,
                                            на которой я сидела. За 3 месяца - 25 кг. Сбылась моя мечта!</p>
                                        <span>Инна, г. Орёл</span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="rev-text rev-text-left">
                                        <p>Мне 52, для профилактики
                                            принимаю <span>НЕЙРОСИСТЕМу 7</span>
                                            курсом каждый год. И вот уже 3 года мой вес стабильно 60 кг. А когда-то был
                                            >89 кг.</p>
                                        <span>Виктория, Черногория. г. Будва</span>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="rev-img">
                                        <img src="img/rev3.png" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="reviews-items visible-xs">
                            <div class="owl-carousel owl3">
                                <div class="rev-item">
                                    <div class="rev-img">
                                        <img src="img/rev1.png" alt="">
                                    </div>
                                    <div class="rev-text">
                                        <p>Мне 36 лет, худела на
                                            <span>НЕЙРОСИСТЕМЕ 7</span> два
                                            месяца. Никто не поверил, что это я!
                                            Думали подменили:))))
                                        </p>
                                        <span>Алина, г. Москва</span>
                                    </div>
                                </div>
                                <div class="rev-item">
                                    <div class="rev-img">
                                        <img src="img/rev2.png" alt="">
                                    </div>
                                    <div class="rev-text">
                                        <p>Мне 41. Подруга рекомендовала
                                            пропить курс <span>НЕЙРОСИСТЕМЫ 7</span>. Самая приятная диета,
                                            на которой я сидела. За 3 месяца - 25 кг. Сбылась моя мечта!
                                        </p>
                                        <span>Инна, г. Орёл</span>
                                    </div>
                                </div>
                                <div class="rev-item">
                                    <div class="rev-img">
                                        <img src="img/rev3.png" alt="">
                                    </div>
                                    <div class="rev-text">
                                        <p>Мне 52, для профилактики
                                            принимаю <span>НЕЙРОСИСТЕМу 7</span>
                                            курсом каждый год. И вот уже 3 года мой вес стабильно 60 кг. А когда-то был
                                            >89 кг.
                                        </p>
                                        <span>Виктория, Черногория. г. Будва</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-sm-1"></div>
            </div>
        </div>
    </section>
    <section class="video">
        <div class="container">
            <div class="section-title">видеоотзыв <span><span>нашей</span> клиентки</span></div>
            <div class="video-wrapper">
                <div class="row">
                    <div class="col-lg-1"></div>
                    <div class="col-lg-10">
                        <iframe src="https://www.youtube.com/embed/6Olnto51vgA" frameborder="0"
                            allowfullscreen></iframe>
                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div>
        </div>
    </section>
    <section class="dobr">
        <div class="container">
            <div class="row">
                <div class="dobr-wrapper">
                    <div class="dobr-wrap">
                        <div class="tochka-left"></div>
                        <div class="tochka-right"></div>
                        <div class="section-title">
                            <span>одобрено</span> на территории рф <img src="img/super.png" alt=""></div>
                    </div>
                    <div class="dobr-items hidden-xs">
                        <div class="col-sm-1"></div>
                        <div class="col-sm-10">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="dobr-item">
                                        <img src="img/dobr1.png" alt="">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="dobr-item">
                                        <img src="img/dobr2.png" alt="">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="dobr-item">
                                        <img src="img/dobr3.png" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-1"></div>
                    </div>
                    <div class="dobr-items visible-xs">
                        <div class="owl-carousel owl4">
                            <div class="dobr-item">
                                <img src="img/dobr1.png" alt="">
                            </div>

                            <div class="dobr-item">
                                <img src="img/dobr2.png" alt="">
                            </div>

                            <div class="dobr-item">
                                <img src="img/dobr3.png" alt="">
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
        </div>
    </section>
    <footer>
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="logo">
                            <img src="img/logo.png" alt="">
                        </div>
                    </div>
                    <div class="col-sm-9">
                        <div class="descr hidden-xs">интеллектуальная формула <span>быстрого похудения</span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-body">
            <div class="container">
                <div class="row">
                    <div class="col-sm-7 col-md-8">
                        <div class="descr1 visible-xs">интеллектуальная формула <span>быстрого похудения</span></div>
                        <div class="descr">Сбросьте лишний вес всего <span>за 7 дней</span></div>
                        <div class="spisok">
                            <ul class="header-ul">
                                <li>Экспресс-потеря веса <span>до 7 кг в неделю</span></li>
                                <li><span>Уничтожение жировых клеток</span> изнутри с 1-го дня</li>
                                <li>Умное похудение <span>без вреда здоровью</span></li>
                            </ul>
                            <img src="img/prod1.png" alt="" class="prod1">
                        </div>
                    </div>
                    <div class="col-sm-5 col-md-4">
                        <div class="forma">
                            <div class="prices">
                                <div class="price-text"><span>только сегодня!</span> цена по акции:</div>
                                <div class="price__new">
                                    <span class="new_price_val">149</span>
                                    <span class="new_price_cur">р</span>
                                </div>
                                <div class="price__old">
                                    <div class="old_price-text">старая цена</div>
                                    <span class="old_price_val">2990</span>
                                </div>
                            </div>
                            <div class="countdown"></div>
                            <form action="js/mail.php" method="post" class="form landing__form" id="form">
							<input type="hidden" name="utm_source" value="">
            <input type="hidden" name="utm_medium" value="Anton lead">
            <input type="hidden" name="utm_campaign" value="">
            <input type="hidden" name="utm_content" value="">
            <input type="hidden" name="utm_term" value="">
                                <div class="form__list">
                                    <div class="form__item">
                                       
                                    </div>
                                    <div class="form__item">
                                        <input type="text" class="form__input" placeholder="Имя" name="name">
                                    </div>
                                    <div class="form__item">
                                        <input type="tel" class="form__input phone__mask" name="phone"
                                            placeholder="Телефон">
                                    </div>
                                    <div class="form__item">
                                        <button class="form__btn">заказать за
                                            <span class="price__new">
                                                <span class="new_price_val">149</span>
                                                <span class="new_price_cur">руб</span>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <div class="pri">*При заказе курса</div>
                            <div class="gost">
                                <img src="img/gost.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <section class="links">
        <div class="container">
            <p>ООО "Росфарм" 113569, г. Москва, Проспект Андропова 22 <br>
                ИНН/КПП 7723657256/753241001 <br>
                ОГРН 563216375904</p>
            <a href="/politic.html">Политика конфиденциальности</a>
            <a href="/oferta.html">Публичная оферта</a>
        </div>
    </section>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.countdown/2.2.0/jquery.countdown.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-url-parser/2.3.1/purl.min.js"></script>
    <script src="https://click.lucky.online/js/leadprofit.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.3.4/jquery.inputmask.bundle.min.js"></script>
  
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(51902759, "init", {
        id:51902759,
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>

			<script type="text/javascript" >
function getUTM2() {
	j = location.search.substring(1).split('&');
	j.forEach(function(el) {
		if (el.substring(0, 4) == 'utm_') {
			k = el.split('=');
			$('input[name=' + k[0] + ']').val(k[1]);
		}
	});
	return;
}

$(document).ready(function() {
	getUTM2();
	$('form').submit(function(e) {
	    i = $(this).find('input[name=phone]').val();
	    if (i == undefined) return true;
    	if (!(/^((8|\+7)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{7,10}$/.test(i))) {
    		alert('\n\nВведен некорректный номер телефона!\n\n');
    		e.preventDefault();
    	}
   		return;
	});
});
</script>
			<!-- counter Roistat -->
 <script>
(function(w, d, s, h, id) {
    w.roistatProjectId = id; w.roistatHost = h;
    var p = d.location.protocol == "https:" ? "https://" : "http://";
    var u = /^.*roistat_visit=[^;]+(.*)?$/.test(d.cookie) ? "/dist/module.js" : "/api/site/1.0/"+id+"/init";
    var js = d.createElement(s); js.charset="UTF-8"; js.async = 1; js.src = p+h+u; var js2 = d.getElementsByTagName(s)[0]; js2.parentNode.insertBefore(js, js2);
})(window, document, 'script', 'cloud.roistat.com', 'dc5a1d5ee96a78db9d2a14afc6d123d6');
</script>
 <!-- counter Roistat -->
<script>
window.onRoistatModuleLoaded = function () {
	roistat.leadHunter.onBeforeSubmit = function(lead) {
		lead.fields.site = "neirosystema-7.ru"; 
	}; 
};
</script>
    <script src="../price.js"></script>
</body>

</html>