<?php
//кому один получатель
$mailto = 'info@moguchij-han.ru';

//от кого письмо
$mailfrom = 'soroka.sonya@yandex.ua';

$subject = 'Заявка с сайта soyuz-apollon.su';


$eol = "\r\n";
$message = '';

$header  = 'From: '.$mailfrom.$eol;
$header .= 'Reply-To: '.$mailfrom.$eol;
$header .= 'MIME-Version: 1.0'.$eol;
$header .= 'Content-type: text/plain; charset=utf-8';

$_POST['name'] = $_REQUEST['name'];
$_POST['phone'] = $_REQUEST['phone'];

$message = 'Имя: '.$_REQUEST['name'].$eol;
$message .= 'Телефон: '.$_REQUEST['phone'].$eol;

$text = '';
if (isset($_POST['query2'])) {
	$text = 'Вас беспокоит: ' . getAnswer($_POST['query2']) . "\n";
	$text.= 'Ваш возраст: ' . $_POST['age'] . "\n";
	$text.= 'Половые инфекции: ' . $_POST['inf'] . "\n";
	$text.= 'Давление: ' . $_POST['pre'] . "\n";
	$text.= 'Половая жизнь: ' . $_POST['sex'] . "\n";
	$text.= 'Симптомы: ' . getAnswer($_POST['query']) . "\n";
	$text.= 'Вредные факторы: ' . getAnswer($_POST['query1']) . "\n";
	$text.= 'Страна: ' . $_POST['country'] . "\n";
	$text.= 'Город: ' . $_POST['town'] . "\n";
	$_POST['text'] = $text;

	$message .= $text;
} else {
	$message .= 'Страна: '.$_REQUEST['country'].$eol;
}

$message .= 'Отправлено с сайта: soyuz-apollon.su'.$eol;
$message .= "IP: {$_SERVER['REMOTE_ADDR']}";

include 'retail.php';
if ($sendMail) {
	mail($mailto, $subject, $message, $header);
}
header( 'Location: success.php', true, 307 );

function getAnswer($a) {
//	$s = Array();
//	foreach($a as $k => $v) $s[] = $k;
	return implode('; ', $a);
}
?>