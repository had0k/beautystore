<!DOCTYPE html>
<html>
<head>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Комбидресс "Slim Shapewear" для коррекции вашей фигуры</title> 
	<meta name="viewport" content="initial-scale=1,user-scalable=no,maximum-scale=1,width=device-width,height=device-height">
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<!--[if IE 9]>
	<link rel="stylesheet" type="text/css" href="stylesheets/ie9.css" />
	<![endif]-->
	<link href="bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="countdown.demo.css" type="text/css">
	<link href="style.css" rel="stylesheet">
	<link href="lobster.css?v=2" rel="stylesheet">
	<link href="myriad.css?v=2" rel="stylesheet">
	<link href="nicolettascript.css?v=2" rel="stylesheet">
	<link href="style1.css?v=2" media="all" type="text/css" rel="stylesheet">
	<link rel="stylesheet" href="css/style4.css">
<meta property="og:type" content="article"/>
<meta property="og:title" content="Комбидресс Slim Shapewear (Low Price)"/>
<meta property="og:description" content="Утягивающее белье нового поколения. Инновационный материал корректирует тело прямо на глазах: приподнимает грудь, очерчивает линию талии, скрывает жировые складки на животе, бедрах и ягодицах."/>
<meta property="og:url" content="https://api.neodvance.com/page/faf0a9ecbaab23520d7ca21cd8bfe8fca5d04ef9"/>

</head>
<body>
	<div class="body_inner" id="top">
		<header id="header">
			<nav class="navbar" role="navigation">
			  <div class="container">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
			        <span class="sr-only">Menu</span>
			        <div class="icon-list"></div>
			      </button>
			    </div>
			    <!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="menu">
			      <ul class="nav navbar-nav">
			      	<li class="active">
				      	<a href="#">
				      		Главная
				      	</a>
			      	</li>
			      	<li>
				      	<a href="#conversion">
				      		Комбидресс
				      	</a>
			      	</li>
			      </ul>
			      <ul class="nav navbar-nav navbar-right">
			      	<li>
				      	<a href="#reviews">
				      		Отзывы
				      	</a>
			      	</li>
			      	<li class="order-link">
				      	<a href="#footer-form">
				      		Заказать
				      	</a>
			      	</li>
			      </ul>
				  <!--<img src="images/arm.png" class="arm visible-lg visible-md" alt="" title="" />-->
			    </div><!-- /.navbar-collapse -->
			  </div><!-- /.container-fluid -->
			</nav>
		</header>
		<main id="main">
			<section class="top-wrap">
				<div class="container banner-wrap">
					<div class="girl-lg visible-lg visible-md">
						<figure class="figure-styled">
							<img src="girl_lg.png" alt="" title="">
						</figure>
					</div>
					<div class="logo">
				      	<p class="bg-logo">
				      		Slim<img src="bg_logo.png" class="logo-img" alt="" title="">
				      	</p>Shapewear
					</div>
					<div style="margin: -15px 0 0 45px; font-weight: 700; font-size: 18px; line-height: 18px; color: #630318; text-transform: uppercase;">Анонимная доставка</div>
					<div class="girl-sm hidden-lg hidden-md img-wrap">
						<figure class="figure-styled">
							<img src="slogan.png" alt="" title="">
						</figure>
					</div>
					<div class="pluses-wrap">
						<ul class="unstyled pluses">
							<li>
								<img src="pluses_item_1.png" alt="" title="">
								<p class="text-styled">
									Уменьшает объем бедер, делает ягодицы визуально упругими и придает им правильную форму
								</p>
							</li>
							<li>
								<img src="pluses_item_2.png" alt="" title="">
								<p class="text-styled">
									Приподнимает грудь,<br> визуально увеличивая её
								</p>
							</li>
							<li>
								<img src="pluses_item_3.png" alt="" title="">
								<p class="text-styled">
									Подтягивает живот,<br> уменьшая линию талии
								</p>
							</li>
							<!-- <li>
							<img src="pluses_item_4.png" alt="" title="">	
								<p class="text-styled">
								<span style="display: none;">	Рекомендовано известными экспертами: Еленой Малышевой и Александром Васильевым*.</span>
								</p>
							</li> -->
						</ul>
						<p class="footnote">
							<span style="display: none;">* Ведущие телепрограмм на первом канале «Жить здорово!» и «Модный приговор»</span>
						</p>
						<ul class="unstyled garanteed">
							<li>
								<img src="garantee_1.png" alt="" title="">
							</li>
							<li>
								<img src="garantee_2.png" alt="" title="">
							</li>
						</ul>
					</div>
				</div><!--end container-->
			</section>
			<section class="form-sale-wrap">
				<div class="container">
					<div class="row row-styled">
						<div class="col-sm-8 sale-wrap">
							<div class="sale-inner">
								<h2 class="header-text">
									Закажите комбидресс
									<p>прямо сейчас!</p>
								</h2>
								<div class="price-wrap">
									<div class="new-price-wrap">	
										<p class="label-styled">
											всего за:
										</p>
										<p class="new-price">
											<span>
                                            1290                                             </span> р.
										</p>
									</div>
									<div class="old-price-wrap">	
										<p class="label-styled">
											вместо:
										</p>
										<p class="old-price">
                                          												<span>
                                            2750                                            </span> р.
                                                												<img src="line.png" class="line" alt="" title="">
										</p>
									</div>
								</div>
								<img src="box.png" class="box-img" alt="" title="">
								<div class="countdown-wrap">
									<p class="header-text">
										Предложение действительно:
									</p>
						            <div class="countbox" style="margin: 20px;"></div>
								</div>
							</div>
						</div>
						<div class="col-sm-4 form-order-wrap">
							<img src="sale.png" alt="" class="sale" title="">
							<form class="main-order-form" method="post" >
								<h3 class="header-text">
									Оставьте заявку для заказа комбидресса со скидкой 53%:
								</h3>
								<div class="form-group">
									<label for="name-top">Ваше имя:</label>
									<input class="form-control" name="name" placeholder="Мария" id="name-top" type="text" required>
								</div>
								<div class="form-group">
									<label for="telephone-top">Ваш телефон: +7...</label>
									<input class="form-control phone" name="phone" id="telephone-top" placeholder="+7..." type="text" required>
								</div>
								<div class="result-price-wrap" style="display: none;">
								</div>
								<p class="explanation">
									Размер и цвет поможет подобрать консультант
								</p>
								<div class="submit-wrap">
									<button class="btn btn-primary btn-primary-styled" id="sendLeadButton">
										Заказать!
									</button>
								</div>
								<div style="margin: 15px 0 0; font-size: 14px; line-height: 20px; text-align: center;">Мы гарантируем полную анонимность доставки. Товар скрывается от любопытных глаз с помощью плотной упаковки, а его описание при отправлении не указывается.</div>
							<input type="hidden" name="l" value="faf0a9ecbaab23520d7ca21cd8bfe8fca5d04ef9" />
<input type="hidden" name="1e4b08e5f4b39fe342182b1f12c904f889d2e3ef" value="ZGVlZDMyNmQ2ZmZkOWEyZGZjNmYyYTZiZjVmMWY1YWQzNjk=" />
</form>
						</div>
					</div><!--end row-->
				</div>
			</section>
			<section class="arguments-wrap">
				<div class="container">
					<ul class="unstyled arguments">
						<li class="sider">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="argument_item_1.png" alt="" title="">
								</figure>
							</div>
							<p>
								Хотите выглядеть стройно и подтянуто?
							</p>
						</li>
						<li class="center-item">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="argument_item_2.png" alt="" title="">
								</figure>
							</div>
							<p>
								Хотите носить облегающую одежду, не стесняясь своих форм?
							</p>
						</li>
						<li class="sider sider-right">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="argument_item_3.png" alt="" title="">
								</figure>
							</div>
							<p>
								Хотите скрыть недостатки фигуры?
							</p>
						</li>
					</ul>
				</div>
			</section>
			<section class="conversion-wrap" id="conversion">
				<div class="container conversion">
					<div class="logo visible-xs visible-sm">
				      	<p class="bg-logo">
				      		Slim<img src="bg_logo.png" class="logo-img" alt="" title="">
				      	</p>Shapewear
					</div>
					<h2 class="header-text">
						Комбидресс
						<div class="logo hidden-xs hidden-sm">
					      	<p class="bg-logo">
					      		Slim<img src="bg_logo.png" class="logo-img" alt="" title="">
					      	</p>Shapewear
						</div><div class="clearfix visible-lg visible-md"></div>преобразит вашу фигуру!
					</h2>
					<div class="inner-list">
						<div class="inner-list-item container-fluid">
							<div class="row">
								<div class="col-sm-5 inner-list-item-img">
									<div class="img-wrap">
										<figure class="figure-styled">
											<img src="conversion_1.png" alt="" title="">
										</figure>
									</div>
								</div>
								<div class="col-sm-7 conversion-pluses-wrap">
									<h3 class="header-text">
										Комбидресс эффективно борется с проблемными зонами:
									</h3>
									<ul class="unstyled conversion-pluses">
										<li>
											<span class="dotted">Живот становится плоским;</span>
										</li>
										<li>
											<span class="dotted">Бедра и ягодицы подтягиваются;</span>
										</li>
										<li>
											<span class="dotted">Складки под мышцами и на спине разглаживаются.</span>
										</li>
									</ul>
								</div>
							</div><!--end row-->
						</div>
					</div>
					<!--<div class="inner-list">
						<div class="inner-list-item container-fluid">
							<div class="row">
								<div class="col-sm-5 inner-list-item-img">
									<div class="img-wrap">
										<figure class="figure-styled">
											<img src="conversion_2.png" alt="" title="">
										</figure>
									</div>
								</div>
								<div class="col-sm-7 conversion-pluses-wrap">
									<h3 class="header-text">
										Ежедневное ношение комбидресса закрепляет результат:
									</h3>
									<ul class="unstyled conversion-pluses">
										<li>
											<span class="dotted">Исчезает эффект «апельсиновой корки»;</span>
										</li>
										<li>
											<span class="dotted">Благодаря невидимому корсету формируется статная осанка;</span>
										</li>
										<li>
											<span class="dotted">Приподнимается бюст, увеличиваясь на 1-2 размера;</span>
										</li>
										<li>
											<span class="dotted">Кожа становится более упругой и шелковистой.</span>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>-->
					<div class="inner-list">
						<div class="inner-list-item container-fluid">
							<div class="row">
								<div class="col-sm-5 inner-list-item-img">
									<div class="img-wrap">
										<figure class="figure-styled">
											<img src="conversion_3.png" alt="" title="">
										</figure>
									</div>
								</div>
								<div class="col-sm-7 conversion-pluses-wrap">
									<h3 class="header-text">
										Утягивающее белье Slim Shapewear дарит вам красоту и комфорт на весь день:
									</h3>
									<ul class="unstyled conversion-pluses">
										<li>
											<span class="dotted">Дышащая ткань дает ощущение свежести;</span>
										</li>
										<li>
											<span class="dotted">Плотное прилегание к телу создает эффект «невидимки»;</span>
										</li>
										<li>
											<span class="dotted">Белье приятно носить — никакого раздражения и дискомфорта;</span>
										</li>
										<li>
											<span class="dotted">Отсутствие швов позволяет надевать облегающие наряды</span>
										</li>
									</ul>
								</div>
							</div><!--end row-->
						</div>
					</div>
				</div>
			</section>
			<section class="effective-wrap">
				<div class="container effective">
					<div class="logo visible-xs visible-sm">
				      	<p class="bg-logo">
				      		Slim<img src="bg_logo.png" class="logo-img" alt="" title="">
				      	</p>Shapewear
					</div>
					<h2 class="header-text">
						Почему корректирующее белье
						<div class="logo hidden-xs hidden-sm">
					      	<p class="bg-logo">
					      		Slim<img src="bg_logo.png" class="logo-img" alt="" title="">
					      	</p>Shapewear
						</div><div class="clearfix visible-lg visible-md"></div>настолько эффективно?
					</h2>
					<!--<p>
						Эффективность корректирующего белья Slim Shapewear достигается за счет его состава — инновационного материала с инкапсулированными активными средствами и специальной пропиткой.
					</p>
					<p>
						При использовании комбидресса микрокапсулы взаимодействуют с кожей, насыщая ее необходимыми компонентами. В результате застоявшаяся жидкость выводится из организма, жировые ткани расщепляются, а кожа увлажняется и получает необходимое питание.
					</p>-->
					<div class="inner-wrap">
						<div class="container-fluid">
							<div class="row">
								<div class="col-sm-5 inner-list-item-img">
									<div class="img-wrap">
										<figure class="figure-styled">
											<img src="effective_img.png" alt="" title="">
										</figure>
									</div>
								</div>
								<div class="col-sm-7 effective-list-wrap">
									<h3 class="header-text">
										На конечный результат работает и специальная конструкция белья:
									</h3>
									<ul class="unstyled effective-list">
										<li>
											<p class="count">
												1
											</p>
											<p class="text-styled">
												Особая конфигурация лифа приподнимает грудь, делая её красивой и соблазнительной.
											</p>
										</li>
										<li>
											<p class="count">
												2
											</p>
											<p class="text-styled">
												Эластичная ткань на поясе изящно очерчивает линию талии.
											</p>
										</li>
										<li>
											<p class="count">
												3
											</p>
											<p class="text-styled">
												Задняя вставка скрывает жировые складки и поддерживает мышцы спины.
											</p>
										</li>
										<li>
											<p class="count">
												4
											</p>
											<p class="text-styled">
												Вшитый треугольник из плотной ткани подтягивает живот, убирая все неровности.
											</p>
										</li>
										<li>
											<p class="count">
												5
											</p>
											<p class="text-styled">
												Эластичные вставки из специального материала моделируют форму бедер и ягодиц.
											</p>
										</li>
									</ul>
								</div>
							</div><!--end row-->
						</div>
					</div>
				</div>
			</section>
			<section class="reviews-wrap" id="reviews">
				<div class="container">
					<div class="header-text">
						<h2>
							Выбор в пользу корректирующего белья сделали: 
						</h2>
						<h3>
							миллионы женщин по всей стране:
						</h3>
					</div>
					<div class="row">
						<div class="col-sm-8 review-item-wrap">
							<div class="review-item">
								<div class="container-fluid">
									<div class="row">
										<div class="col-sm-4 review-item-img">
											<div class="img-wrap">
												<figure class="figure-styled">
													<img src="review_img_1.png" alt="" title="">
												</figure>
											</div>
										</div>
										<div class="col-sm-8 review-item-text">
											<h4>
												«Не верила, что возможно носить одежду на 2-3 размера меньше»
											</h4>
											<p>
												Признаться честно — не верила, что возможно носить одежду на 2-3 размера меньше. Но когда примерила — поняла, что это мое!!! Теперь на работе коллеги спрашивают рецепт диеты )
											</p>
										</div>
									</div><!--end row-->
								</div>
							</div>
							<div class="review-item">
								<div class="container-fluid">
									<div class="row">
										<div class="col-sm-4 review-item-img">
											<div class="img-wrap">
												<figure class="figure-styled">
													<img src="review_img_2.png" alt="" title="">
												</figure>
											</div>
										</div>
										<div class="col-sm-8 review-item-text">
											<h4>
												«Появилось даже очертание талии!»
											</h4>
											<p>
												У меня 52 размер. Комбидресс и правда утягивает живот, складки по бокам и бедрам. Появилось даже очертание талии, что вдвойне приятно. Теперь самой на себя приятнее взглянуть.
											</p>
										</div>
									</div><!--end row-->
								</div>
							</div>
						</div>
						<div class="col-sm-4 celebrities-wrap" style="display: none;">
							<p class="header-text">
								звезды эстрады:
							</p>
							<ul class="unstyled celebreties">
								<li>
									<figure>
										<img src="celebreties_1.png" alt="" title="">
									</figure>
									<p>
										Лера Кудрявцева
									</p>
								</li>
								<li>
									<p>
										Дженнифер Лопес
									</p>
									<figure>
										<img src="celebreties_2.png" alt="" title="">
									</figure>
								</li>
								<li>
									<figure>
										<img src="celebreties_3.png" alt="" title="">
									</figure>
									<p>
										Вера Брежнева
									</p>
								</li>
							</ul>
						</div>
					</div><!--end row-->
				</div>
			</section>
		</main>
		<footer id="footer">
			<section class="form-sale-wrap">
				<div class="container">
					<div class="row row-styled">
						<div class="col-sm-8 sale-wrap">
							<div class="sale-inner">
								<h2 class="header-text">
									Закажите комбидресс
									<p>прямо сейчас!</p>
								</h2>
								<div class="price-wrap">
									<div class="new-price-wrap">	
										<p class="label-styled">
											всего за:
										</p>
										<p class="new-price">
											<span>
                                            1290                                             </span> р.
										</p>
									</div>
									<div class="old-price-wrap">	
										<p class="label-styled">
											вместо:
										</p>
										<p class="old-price">
											                    												<span>
                                            2750                                            </span> р.
                                                	                                                <img src="line.png" class="line" alt="" title="">
										</p>
									</div>
								</div>
								<img src="box.png" class="box-img" alt="" title="">
								<div class="countdown-wrap">
									<p class="header-text">
										Предложение действительно:
									</p>
						            <div class="countbox" style="margin: 20px;"></div>
								</div>
							</div>
							<div class="caution-wrap hidden-xs">
								<p class="caution">
									Ваши данные третьим лицам не разглашаются!
								</p>
							</div>
						</div>
						<div class="col-sm-4 form-order-wrap">
							<img src="sale.png" alt="" class="sale" title="">
							<form class="main-order-form" method="post" >
								<h3 class="header-text">
									Оставьте заявку для заказа комбидресса со скидкой 53%:
								</h3>
								<div class="form-group">
									<label for="name-footer">Ваше имя:</label>
									<input value="" class="form-control" name="name" placeholder="Мария" id="name-footer" type="text" required>
								</div>
								<div class="form-group">
									<label for="telephone-footer">Ваш телефон: +7...</label>
									<input class="form-control phone" name="phone" id="telephone-footer" placeholder="+7..." type="text" required>
								</div>
								<p class="explanation">
									Размер и цвет поможет подобрать консультант
								</p>
								<div class="submit-wrap">
									<button class="btn btn-primary btn-primary-styled" id="sendLeadButton2">
										Заказать!
									</button>
								</div>
								<div style="margin: 15px 0 0; font-size: 14px; line-height: 20px; text-align: center;">Мы гарантируем полную анонимность доставки. Товар скрывается от любопытных глаз с помощью плотной упаковки, а его описание при отправлении не указывается.</div>
								<div class="caution-wrap visible-xs">
									<p class="caution">
										Ваши данные третьим лицам не разглашаются!
									</p>
								</div>
							<input type="hidden" name="l" value="faf0a9ecbaab23520d7ca21cd8bfe8fca5d04ef9" />
<input type="hidden" name="1e4b08e5f4b39fe342182b1f12c904f889d2e3ef" value="ZGVlZDMyNmQ2ZmZkOWEyZGZjNmYyYTZiZjVmMWY1YWQzNjk=" />
</form>
						</div>
					</div><!--end row-->
				</div>
			</section>
			            <!--				Тригеры доверия		-->
			<section class="how-wrap1">
				<div class="container">
					<h2 style="margin-top: 20px;" class="header-text">
						Почему 30876 клиентов доверяют нам?
					</h2>
					<div class="row row-styled ">
						<div style="margin-bottom: 15px;" class="col-md-3 col-sm-6">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="icon-1.png" alt="" title="">
								</figure>
							</div>
							<h4 style="font-weight: 900; text-align: center;">
								100% ПОПАДАНИЕ В РАЗМЕР!
							</h4>
							<p class="how-text">
								Мы подберем для Вас оптимальный размер комбидресса.
							</p>
						</div>
						<div style="margin-bottom: 15px;" class="col-md-3 col-sm-6">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="icon-2.png" alt="" title="">
								</figure>
							</div>
							<h4 style="font-weight: 900; text-align: center;">
								ЕВРОПЕЙСКОЕ КАЧЕСТВО ИЗДЕЛИЯ!
							</h4>
							<p class="how-text">
								Конструкция и состав ткани разработаны в Европе.
							</p>
						</div>
						<div style="margin-bottom: 15px;" class="col-md-3 col-sm-6">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="icon-3.png" alt="" title="">
								</figure>
							</div>
									<h4 style="font-weight: 900; text-align: center;">
								ОПЛАТА ТОЛЬКО ПРИ ПОЛУЧЕНИИ!
							</h4>
							<p class="how-text">
								Вы оплачиваете товар только при получении товара на руки.
							</p>
						</div>
						<div style="margin-bottom: 15px;" class="col-md-3 col-sm-6">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="icon-4.png" alt="" title="">
								</figure>
							</div>
									<h4 style="font-weight: 900; text-align: center;">
								ГАРАНТИЯ ОБМЕНА И ВОЗВРАТА!
							</h4>
							<p class="how-text">
								Если Вы получите товар ненадлежащего качества, то мы бесплатно обменяем его или вернем деньги.</p>
						</div>
					</div>
				</div>
			</section>
			<section class="how-wrap">
				<div class="container">
					<h2 class="header-text">
						Как мы работаем
					</h2>
					<div class="row row-styled">
						<div class="col-md-3 col-sm-6">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="how_img_1.png" alt="" title="">
								</figure>
							</div>
							<p class="how-text">
								Вы оставляете заявку на сайте или по телефону.
							</p>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="how_img_2.png" alt="" title="">
								</figure>
							</div>
							<p class="how-text">
								Менеджер связывается с Вами для подтверждения заказа.
							</p>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="how_img_3.png" alt="" title="">
								</figure>
							</div>
							<p class="how-text">
								Мы быстро доставляем Вашу посылку по указанному адресу.
							</p>
						</div>
						<div class="col-md-3 col-sm-6">
							<div class="img-wrap">
								<figure class="figure-styled">
									<img src="how_img_4.png" alt="" title="">
								</figure>
							</div>
							<p class="how-text">
								Вы получаете свой товар и оплачиваете на почте.							</p>
						</div>
					</div>
				</div>
			</section>
			<nav class="navbar" role="navigation">
			  <div class="container">
			    <!-- Collect the nav links, forms, and other content for toggling -->
			      <ul class="nav navbar-nav navbar-right">
			      	<li>
				      	<a href="#top">
				      		Главная
				      	</a>
			      	</li>
			      	<li>
				      	<a href="#conversion">
				      		Комбидресс
				      	</a>
			      	</li>
			      	<li>
				      	<a href="#reviews">
				      		Отзывы
				      	</a>
			      	</li>
			      	<li class="order-link">
				      	<a href="#footer">
				      		Заказать
				      	</a>
			      	</li>
			      </ul>
			      	<p class="copyright">
			      		© 2020 <span class="hidden-sm">Все права защищены</span>
			      	</p>
			  </div><!-- /.container-fluid -->
			</nav>
		</footer>
		<div style="text-align: center; padding: 15px 0;">
  <img src="assets_pages/copyrights/0/black-320.png" alt="copyright">
          <p style="text-align: center">
                <a href="politics.html">Политика конфиденциальности</a>
                <a href="agreement.html">Пользовательское соглашение</a>
          </p>
		</div>
	</div>
</div>

    <script type="text/javascript">
        var phonePrefix = '+7';
    </script>
    <script type="text/javascript" src="assets_pages/js/phonePrefix.js"></script>



<script>
    var comebackerFormId = '4';
</script>

<link href="assets_pages/css/popup-m1-style.css?v=0.0.3" rel="stylesheet" type="text/css"/>
<script src="assets_pages/js/popup-m1.js?v=0.0.1" type="text/javascript"></script>

<div id="overlay-popup-m1"></div>
<div id="m1-form" class="m1modal">
    <a class="close-m1"></a>
    <div><div class="popup-m1-title">Вам понравилось это предложение?</div>
        <div class="popup-m1-cont">
            <div class="popup-m1-text1">Мы расскажем Вам все об этом товаре, предложим наилучшие условия и ознакомим с подходящими акционными предложениями!</div>
            <form method="post" action="" class="main-order-form popup-m1-form" onsubmit="return false;">
                <input type="text" name="name" placeholder="Введите ваше имя" required />
                <input type="tel" name="phone" placeholder="Введите телефон" required />
                <button>Перезвоните мне</button>
                <input type="hidden" name="is_popup" value="1" />
                <input type="hidden" name="from_recall_button" value="0" />
                <input type="hidden" name="form_id">
                <input type="hidden" name="l" value="faf0a9ecbaab23520d7ca21cd8bfe8fca5d04ef9" />
                <input type="hidden" name="1e4b08e5f4b39fe342182b1f12c904f889d2e3ef" value="ZGVlZDMyNmQ2ZmZkOWEyZGZjNmYyYTZiZjVmMWY1YWQzNjk=" />
            </form>
                            <div class="popup-m1-text2">Оператор перезвонит Вам через 5-10 минут</div>
                    </div>
    </div>
</div>

<script type="text/javascript">
    $(function(){
        M1.initComebacker(3000);

            });
</script>





<script type="text/javascript" src="assets_pages/js/m1ref.js"></script>
<script type="text/javascript"> 
var m1_product_id = 3449;
var ref = 273827;
var script = document.createElement("script");
script.src = "//m1-shop.ru/send_order/?ref="+ref+"&s="+getC("s")+"&w="+getC("w")+"&t="+getC("t")+"&p="+getC("p")+"&m="+getC("m")+"&product_id="+m1_product_id+'&out=1';
document.body.appendChild(script);
</script>

<script type="text/javascript">

var QueryString = function () {
    var query_string = {};
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i=0;i<vars.length;i++) {
        var pair = vars[i].split("=");
        if (typeof pair[0]!='undefined'
            && typeof pair[1]!='undefined'
            && pair[1].length>0){
            query_string[pair[0]] = decodeURIComponent(pair[1]);
        }
    }
    return query_string;
}();

/* user parameters */
var webmaster_id = 273827,
    webmaster_api = '14e619ab52dc73faf9c37b52b0c2735d',
    product_id = '3449',
    ldlId = '8147';

/* not change */
var client_ip = '127.0.0.1';
var clientMark = [];
var markList = ['s','w','t','p','m'];

function sendData(client_name, client_phone) {
    var detectsString = '';
    var markQuery = clientMark.length>0 ? clientMark.join('&') : '';
    var comment = $("[name=comment]").val();
    if (typeof detects !== 'undefined') {
        detectsString = JSON.stringify(detects);
        detectsString = detectsString.replace(/"/g,"'");
    }
    $.ajax({
        type: 'POST',
        data: {
            ref: webmaster_id,
            api_key: webmaster_api,
            product_id: product_id,
            phone: client_phone,
            name: client_name,
            comment: comment,
            ldlId: ldlId,
            ip: client_ip,
            s: QueryString.s,
            w: QueryString.w,
            t: QueryString.t,
            p: QueryString.p,
            m: QueryString.m,
            referer: document.referrer,
            detects: detectsString
            },
        url: '//m1-shop.ru/send_order/',
        success: function(data) {
            data = JSON.parse(data);
            if (data.result == "ok") {
                markQuery = markQuery.length ? '&'+markQuery : '';
                window.location.replace("success.php?order_id=" + data.id + markQuery);
            }
            else {
                markQuery = markQuery.length ? '?'+markQuery : '';
                window.location.replace("success.php"+markQuery);
            }
        },
        error: function(xhr, status, error) {
            console.log(xhr.statusText, xhr.responseText, status, error);
            respjs = JSON.parse(xhr.responseText);
            markQuery = markQuery.length ? '?'+markQuery: '';
            window.location.replace("success.php"+markQuery);
        }
    });
    return false;
};


$(document).ready(function() {
    var query = QueryString;

    for(var i in markList){
        var mark = markList[i];
        if (typeof query[mark]!='undefined'
            &&query[mark].length){
            clientMark.push(mark+'='+query[mark]);
        }
    }

    $.getJSON('https://api.ipify.org/?format=json', function(data) {
        client_ip = data.ip;
    });

    $(document).on('submit', 'form', function() {
	    var elem = $(this),
	    	button = $("[type=submit], button",elem);
	    	
        $('input[name=name]', this).val($.trim($('input[name=name]', this).val()));
        if (!$('input[name=name]', this).val()) {
            alert('Укажите корректные ФИО!');
            return false;
        }

        if (!$('input[name=phone]', this).val() || $('input[name=phone]', this).val().length < 7) {
            alert('Укажите корректный телефон!');
            return false;
        }
        
        button.prop("disabled",true);
        sendData($('input[name=name]', this).val(), $('input[name=phone]', this).val());
        return false;
    });

    var product = 3449,
        url = location.href,
        length = 0,
        keyVal = '',
        arFio = [],
        arPhone = [];

    $('input[name="phone"]').bind('keyup change', function(){
        var form = $(this).parents('form'),
            name = form.find('input[name="name"]').val(),
            phone = $(this).val().replace(/\D+/g, '');

        if (phone.length >= 8) {
            getFormData();
            $.ajax({
                type: 'POST',
                url: '//m1-shop.ru/send_stat_order/',
                data: {
                    name: name,
                    phone: phone,
                    name_json: JSON.stringify(arFio),
                    phone_json: JSON.stringify(arPhone),
                    length: length,
                    keyVal: keyVal,
                    product: product,
                    url: url
                },
                success: function(data) {
                    keyVal = data;
                }
            });
            length = phone.length;
        }
    });

    $('form').submit(function(){
        if (keyVal.length) {
            $.ajax({
                type: 'POST',
                url: '//m1-shop.ru/send_stat_order/',
                data: {
                    del: 1,
                    keyVal: keyVal
                }
            });
        }
    });

    function getFormData() {
        arFio = [];
        arPhone = [];
        $('form').each(function(){
            var phone = $(this).find('input[name="phone"]').val();
            var fio = $(this).find('input[name="name"]').val();
            phone = phone.replace(/\D+/g,'');
            if (phone.length >= 8){
                arPhone.push(phone.toString());
                if (typeof fio != 'undefined')
                    arFio.push(fio.toString());
            }
        });
    }
});
</script>








<script src="assets_pages/land/js/youtube/previewYouTube.js"></script>
<script type="text/javascript">
$(function(){
        $("a[href^='#']").click(function(){
                var _href = $(this).attr("href");
                $("html, body").animate({scrollTop: $(_href).offset().top+"px"});
                return false;
        });
});
</script>
<script src="js/count.js"></script>
</body>
</html>